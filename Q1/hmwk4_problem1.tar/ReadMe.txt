Running hmwk4 to get the distribution of reflection degree for any effective incident angle

Running hmwk4_test to get the file of special incident condition.

Running script.gnu to profuce plots of files.
