Running hmwk4_2 to get the two files of "photons vs time","photons vs radius" seperately

Running script.gnu to profuce plots of files.
ps1:the unit of x axis is nanoseconds & decimeter)
ps2:the ""photons vs time" graph shows the pulse where photon detecter get the signal first, then it should keep const and stable.
